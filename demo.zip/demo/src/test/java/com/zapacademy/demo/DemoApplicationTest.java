package com.zapacademy.demo;

import static org.junit.jupiter.api.Assertions.*;

class DemoApplicationTest {

}